import Lake
open Lake DSL

package «gz_stage_d_dynamics_q0» where
  leanOptions := #[
    ⟨`autoImplicit, false⟩
  ]

lean_lib «StageA» where
  roots := #[`StageA]

lean_lib «StageB» where
  roots := #[`StageB]

lean_lib «StageC» where
  roots := #[`StageC]

lean_lib «StageD» where
  roots := #[`StageD]

@[default_target]
lean_exe «stage_d_audit» where
  root := `Main
