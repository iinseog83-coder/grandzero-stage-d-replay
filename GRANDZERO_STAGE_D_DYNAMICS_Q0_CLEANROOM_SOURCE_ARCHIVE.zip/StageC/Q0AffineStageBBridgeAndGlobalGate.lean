/-
  GRANDZERO Ω — Stage C (Finite Rational Cellular Sheaf & Global Consistency Gate)
  Module C-4: Q0AffineStageBBridgeAndGlobalGate.lean
  Scope:
    1. Sound connection from the Exact Affine Subcategory of `Stage B` expressions
       (`affineLinearExpr`, `checkExactAffineEquiv`, `thm_exact_affine_bridge_sound`,
       keeping nonlinear `Stage B` bridges explicitly `HELD`).
    2. Global Constrained Solution Set `InGlobalSolutionSet` (`S = {x | δ⁰x=η, Ax=c, Ω(x)}`)
       and `GlobalUnsatCertQ0` (`Tribunal Condition B`: `thm_stageC_anchor_guard_unsat_sound`
       proving `S = ∅` via affine Farkas duals, pinned-stalk propagation, or `StageB.EmptyOverlapCertQ0`).
    3. Deterministic 7-stage precedence `auditCellularSheafGate` (`Tribunal Condition C`)
       and complete soundness & pairwise mutual-exclusion theorems across all outcomes.
-/

import StageC.Q0CohomologyAndH1Quotient

namespace GrandZero.StageC

open GrandZero.StageA
open GrandZero.StageB

/-! ### Part 1: Sound Exact-Affine Bridge from `Stage B` (`__NONLINEAR_STAGE_B_COMPATIBILITY_HELD`) -/

/-- Build an explicit affine-linear `ExprQ0`: `b_{u_out} + ∑_{j < m} (a_j)_{w_j} * x_j`. -/
def buildAffineSumAux (m : Nat) (a : VecQ0 m) (w : Fin m → UnitSpecQ0) (u_out : UnitSpecQ0) :
    (k : Nat) → k ≤ m → ExprQ0
  | 0, _ => .ratLit 0 u_out
  | k + 1, hle =>
      let idx : Fin m := ⟨k, hle⟩
      .binOp .add
        (buildAffineSumAux m a w u_out k (Nat.le_of_lt hle))
        (.binOp .mul (.ratLit (a idx) (w idx)) (.bvar k))

def affineLinearExpr (Γ : VarCtxQ0) (a : VecQ0 Γ.length)
    (w : Fin Γ.length → UnitSpecQ0) (b : Rat) (u_out : UnitSpecQ0) : ExprQ0 :=
  .binOp .add (.ratLit b u_out) (buildAffineSumAux Γ.length a w u_out Γ.length (Nat.le_refl _))

/-- Whitebox check certifying that an arbitrary `Stage A / B` expression `e` is
    globally unit-identical and `StrongEq`-equivalent (with zero poles!) to the
    exact affine form `affineLinearExpr Γ a w b u_out`. Nonlinear or rational-pole
    expressions (such as `TB-02`'s `v / (1 + κ v)`) automatically fail this gate. -/
def checkExactAffineEquiv
    (Γ : VarCtxQ0) (e : ExprQ0)
    (a : VecQ0 Γ.length) (w : Fin Γ.length → UnitSpecQ0)
    (b : Rat) (u_out : UnitSpecQ0) : Bool :=
  (synthUnit Γ (affineLinearExpr Γ a w b u_out) == some u_out) &&
  (auditProof Γ [] [] (.gprAstCert [] []) e (affineLinearExpr Γ a w b u_out) == SyndromeQ0.zero)

/-- Target Theorem `thm_exact_affine_bridge_sound`:
    Whenever `checkExactAffineEquiv` passes, `e` has zero unguarded poles and agrees
    via `StrongEq` with the exact affine expression at EVERY `ρ` modeling `Γ`. -/
theorem thm_exact_affine_bridge_sound
    (Γ : VarCtxQ0) (e : ExprQ0)
    (a : VecQ0 Γ.length) (w : Fin Γ.length → UnitSpecQ0)
    (b : Rat) (u_out : UnitSpecQ0)
    (hchk : checkExactAffineEquiv Γ e a w b u_out = true) :
    synthUnit Γ e = some u_out ∧
    ∀ ρ : List Rat, EnvModelsCtx ρ Γ →
      StrongEq ρ e (affineLinearExpr Γ a w b u_out) := by
  unfold checkExactAffineEquiv at hchk
  simp only [Bool.and_eq_true, beq_iff_eq] at hchk
  rcases hchk with ⟨hu_aff, haud⟩
  rcases thm_syndrome_sound (.gprAstCert [] []) Γ [] [] e (affineLinearExpr Γ a w b u_out) haud with
    ⟨⟨u, hu_e, hu_aff'⟩, hstrong⟩
  rw [hu_aff] at hu_aff'
  injection hu_aff' with hu_eq
  subst hu_eq
  refine ⟨hu_e, fun ρ henv => ?_⟩
  exact hstrong ρ henv (fun _ hm => by simp at hm) (fun _ hm => by simp at hm)

/-! ### Part 2: Global Constrained Solution Set `S` & `Condition B` Unsatisfiability Certificates -/

/-- Exact global constrained solution set `S = {x ∈ C⁰ | δ⁰ x = η ∧ A_pin x = c_pin ∧ ∀ v, ValidDomainQ0 x_v C_v}`. -/
def InGlobalSolutionSet
    (S : CellularSheafQ0) (η : VecQ0 S.N1)
    {nPin : Nat} (Apin : MatQ0 nPin S.N0) (cpin : VecQ0 nPin)
    (x : VecQ0 S.N0) : Prop :=
  matVec (assembleDelta0 S) x = η ∧
  matVec Apin x = cpin ∧
  ∀ v : Fin S.nV, ValidDomainQ0 (extractVertexList S x v) (S.vCtx v)

/-- Computable membership checker for `InGlobalSolutionSet`. -/
def checkInGlobalSolutionSet
    (S : CellularSheafQ0) (η : VecQ0 S.N1)
    {nPin : Nat} (Apin : MatQ0 nPin S.N0) (cpin : VecQ0 nPin)
    (x : VecQ0 S.N0) : Bool :=
  vecEqBool (matVec (assembleDelta0 S) x) η &&
  vecEqBool (matVec Apin x) cpin &&
  allFin S.nV (fun v => checkValidDomainQ0 (extractVertexList S x v) (S.vCtx v))

theorem lem_checkInGlobalSolutionSet_iff
    (S : CellularSheafQ0) (η : VecQ0 S.N1)
    {nPin : Nat} (Apin : MatQ0 nPin S.N0) (cpin : VecQ0 nPin)
    (x : VecQ0 S.N0) :
    checkInGlobalSolutionSet S η Apin cpin x = true ↔
      InGlobalSolutionSet S η Apin cpin x := by
  unfold checkInGlobalSolutionSet InGlobalSolutionSet
  simp only [Bool.and_eq_true, vecEqBool_iff, allFin_iff, lem_checkValidDomain_iff]
  exact ⟨fun ⟨⟨h1, h2⟩, h3⟩ => ⟨h1, h2, h3⟩, fun ⟨h1, h2, h3⟩ => ⟨⟨h1, h2⟩, h3⟩⟩

/-- Coordinate selector matrix `E_v ∈ ℚ^{d_v × N_0}` extracting vertex `v`'s stalk vector. -/
def vertexSelectorMat (S : CellularSheafQ0) (v : Fin S.nV) : MatQ0 (S.dV v) S.N0 :=
  fun j J => if (encodeBlockIdx S.nV S.dV v j).val = J.val then 1 else 0

theorem matVec_vertexSelectorMat (S : CellularSheafQ0) (v : Fin S.nV) (x : VecQ0 S.N0) :
    matVec (vertexSelectorMat S v) x = extractVertexVec S x v := by
  funext j
  unfold matVec vertexSelectorMat extractVertexVec
  let idx0 : Fin S.N0 := encodeBlockIdx S.nV S.dV v j
  have heq : finSum S.N0 (fun J : Fin S.N0 => (if idx0.val = J.val then (1 : Rat) else 0) * x J) =
      finSum S.N0 (fun J : Fin S.N0 => (if idx0 = J then (1 : Rat) else 0) * x J) := by
    apply finSum_ext
    intro J
    by_cases h : idx0 = J
    · subst h; simp
    · have hv : idx0.val ≠ J.val := fun hc => h (Fin.ext hc)
      simp [h, hv]
  exact heq.trans (finSum_delta_left S.N0 idx0 x)

/-- Whitebox global unsatisfiability certificate (`Tribunal Condition B`) proving `S = ∅`:
    1. `affineFarkasDual`: dual vector `(w0, wPin)` proving `[δ⁰ ; A_pin] x = [η ; c_pin]` has no solution.
    2. `pinnedStalkDomainViolation`: row operators `(W0, WPin)` proving `W0 δ⁰ + WPin A_pin = E_v`
       (uniquely forcing `x_v = W0 η + WPin c_pin` for every linear solution `x`), where that forced
       stalk value violates `checkValidDomainQ0` (e.g. `x_v > 0` guard failure)!
    3. `intrinsicVertexEmptyOverlap`: `StageB.EmptyOverlapCertQ0` (Farkas cone or SOS squares)
       proving `Real_ℚ(S.vCtx v) = ∅` globally. -/
inductive GlobalUnsatCertQ0 (S : CellularSheafQ0) (nPin : Nat) where
  | affineFarkasDual
      (w0   : VecQ0 S.N1)
      (wPin : VecQ0 nPin)
  | pinnedStalkDomainViolation
      (v    : Fin S.nV)
      (W0   : MatQ0 (S.dV v) S.N1)
      (WPin : MatQ0 (S.dV v) nPin)
  | intrinsicVertexEmptyOverlap
      (v         : Fin S.nV)
      (emptyCert : EmptyOverlapCertQ0)

def checkGlobalUnsatCert
    (S : CellularSheafQ0) (η : VecQ0 S.N1)
    {nPin : Nat} (Apin : MatQ0 nPin S.N0) (cpin : VecQ0 nPin) :
    GlobalUnsatCertQ0 S nPin → Bool
  | .affineFarkasDual w0 wPin =>
      vecEqBool
        (addVec (matVec (transposeMat (assembleDelta0 S)) w0)
                (matVec (transposeMat Apin) wPin))
        (zeroVec S.N0) &&
      decide (dotVec w0 η + dotVec wPin cpin ≠ 0)
  | .pinnedStalkDomainViolation v W0 WPin =>
      matEqBool
        (addMat (matMul W0 (assembleDelta0 S)) (matMul WPin Apin))
        (vertexSelectorMat S v) &&
      !checkValidDomainQ0
        (vecToList (addVec (matVec W0 η) (matVec WPin cpin)))
        (S.vCtx v)
  | .intrinsicVertexEmptyOverlap v emptyCert =>
      checkEmptyOverlapCert (S.vCtx v) emptyCert

/-- Target Theorem `thm_stageC_anchor_guard_unsat_sound` (`Tribunal Condition B`):
    Any accepted `GlobalUnsatCertQ0` proves universally that the global constrained
    solution set `S` is EMPTY (`∀ x ∈ C⁰, ¬ InGlobalSolutionSet S η Apin cpin x`). -/
theorem thm_stageC_anchor_guard_unsat_sound
    (S : CellularSheafQ0) (η : VecQ0 S.N1)
    {nPin : Nat} (Apin : MatQ0 nPin S.N0) (cpin : VecQ0 nPin)
    (uc : GlobalUnsatCertQ0 S nPin)
    (huc : checkGlobalUnsatCert S η Apin cpin uc = true) :
    ∀ x : VecQ0 S.N0, ¬ InGlobalSolutionSet S η Apin cpin x := by
  intro x ⟨hd0x, hpinx, hdom⟩
  cases uc with
  | affineFarkasDual w0 wPin =>
      simp only [checkGlobalUnsatCert, Bool.and_eq_true, vecEqBool_iff, decide_eq_true_eq] at huc
      rcases huc with ⟨hzero, hnz⟩
      have hsum : dotVec w0 η + dotVec wPin cpin =
          dotVec (addVec (matVec (transposeMat (assembleDelta0 S)) w0)
                         (matVec (transposeMat Apin) wPin)) x := by
        rw [← hd0x, ← hpinx, dotVec_matVec_transpose, dotVec_matVec_transpose]
        unfold dotVec addVec
        rw [← finSum_add]
        apply finSum_ext
        intro j
        grind
      rw [hzero, dotVec_zero_left] at hsum
      exact hnz hsum
  | pinnedStalkDomainViolation v W0 WPin =>
      simp only [checkGlobalUnsatCert, Bool.and_eq_true, matEqBool_iff, Bool.not_eq_true'] at huc
      rcases huc with ⟨hmat_eq, hnot_valid⟩
      have hxv : extractVertexVec S x v = addVec (matVec W0 η) (matVec WPin cpin) := by
        calc
          extractVertexVec S x v
              = matVec (vertexSelectorMat S v) x := (matVec_vertexSelectorMat S v x).symm
          _ = matVec (addMat (matMul W0 (assembleDelta0 S)) (matMul WPin Apin)) x := by
                rw [← hmat_eq]
          _ = addVec (matVec (matMul W0 (assembleDelta0 S)) x) (matVec (matMul WPin Apin) x) :=
                addMat_vec _ _ x
          _ = addVec (matVec W0 (matVec (assembleDelta0 S) x)) (matVec WPin (matVec Apin x)) := by
                rw [matVec_matMul, matVec_matMul]
          _ = addVec (matVec W0 η) (matVec WPin cpin) := by
                rw [hd0x, hpinx]
      have hv_valid : checkValidDomainQ0 (extractVertexList S x v) (S.vCtx v) = true :=
        (lem_checkValidDomain_iff _ _).mpr (hdom v)
      unfold extractVertexList at hv_valid
      rw [hxv] at hv_valid
      rw [hnot_valid] at hv_valid
      contradiction
  | intrinsicVertexEmptyOverlap v emptyCert =>
      simp only [checkGlobalUnsatCert] at huc
      exact thm_empty_overlap_sound (S.vCtx v) emptyCert huc (extractVertexList S x v) (hdom v)

/-! ### Part 3: Deterministic 7-Stage Precedence Gate (`Tribunal Condition C`) -/

/-- Strict 6-way Stage C Gate Outcome (`Tribunal Condition C`). -/
inductive StageCGateOutcomeQ0 where
  | verifiedCompatGlobalSection          : (h0 h1 : Nat) → StageCGateOutcomeQ0
  | verifiedCohomologyObstruction        : (h0 h1 : Nat) → StageCGateOutcomeQ0
  | verifiedFaceCurvatureFailure         : (h0 h1 : Nat) → StageCGateOutcomeQ0
  | verifiedAnchorOrGuardIncompatibility : (h0 h1 : Nat) → StageCGateOutcomeQ0
  | rejectedInvalidComplexOrSheaf        : StageCInvalidReasonQ0 → StageCGateOutcomeQ0
  | rejectedInvalidCertificate           : StageCGateOutcomeQ0
  deriving DecidableEq, Repr, Inhabited

/-- Mode-specific witness payload paired with a mandatory `CohomologyComplementBasis`. -/
inductive StageCWitnessPayloadQ0 (S : CellularSheafQ0) (nPin : Nat) where
  | curvatureClaim         : StageCWitnessPayloadQ0 S nPin
  | cohomologyObstruction  : (yDual : VecQ0 S.N1) → StageCWitnessPayloadQ0 S nPin
  | anchorOrGuardUnsat     : GlobalUnsatCertQ0 S nPin → StageCWitnessPayloadQ0 S nPin
  | compatGlobalSection    : (xSol : VecQ0 S.N0) → StageCWitnessPayloadQ0 S nPin

structure StageCCertBundleQ0 (S : CellularSheafQ0) (nPin : Nat) where
  cohomCert : CohomologyComplementBasis S.N0 S.N1 S.N2
  payload   : StageCWitnessPayloadQ0 S nPin

/-- Trusted Deterministic 7-Stage Cellular Sheaf Global Consistency Gate (`Tribunal Condition C`):
    `1. Boundary Nilpotence` → `2. Stalk/Matrix Units` → `3. Sheaf Functoriality` →
    `4. Cochain Nilpotence` → `5. Authority Global Meet` → `6. CohomologyComplementBasis` →
    `7. Curvature → H¹ Obstruction → Certified S = ∅ → Verified Section x ∈ S`. -/
def auditCellularSheafGate
    (S : CellularSheafQ0) (η : VecQ0 S.N1)
    {nPin : Nat} (Apin : MatQ0 nPin S.N0) (cpin : VecQ0 nPin)
    (bundle : StageCCertBundleQ0 S nPin) : StageCGateOutcomeQ0 :=
  match validateSheafComplexStructure S with
  | some invalidReason =>
      .rejectedInvalidComplexOrSheaf invalidReason
  | none =>
      let δ0 := assembleDelta0 S
      let δ1 := assembleDelta1 S
      let cc := bundle.cohomCert
      if !checkCohomologyCert δ0 δ1 cc then
        .rejectedInvalidCertificate
      else
        let h0 := cc.rn0.k
        let h1 := cc.h1
        -- Stage 7a: Non-cocycle 2-face curvature (`δ¹ η ≠ 0`)
        if !vecEqBool (matVec δ1 η) (zeroVec S.N2) then
          match bundle.payload with
          | .curvatureClaim => .verifiedFaceCurvatureFailure h0 h1
          | _               => .rejectedInvalidCertificate
        -- Stage 7b: Genuine 1-cocycle cohomology obstruction (`δ¹ η = 0 ∧ LH η ≠ 0`)
        else if !vecEqBool (matVec cc.LH η) (zeroVec cc.h1) then
          match bundle.payload with
          | .cohomologyObstruction yDual =>
              if checkDualObstruction δ0 η yDual then
                .verifiedCohomologyObstruction h0 h1
              else
                .rejectedInvalidCertificate
          | _ => .rejectedInvalidCertificate
        -- Stage 7c/7d: Exact coboundary (`δ¹ η = 0 ∧ LH η = 0`, hence `η ∈ im(δ⁰)`)
        else
          match bundle.payload with
          | .anchorOrGuardUnsat uc =>
              if checkGlobalUnsatCert S η Apin cpin uc then
                .verifiedAnchorOrGuardIncompatibility h0 h1
              else
                .rejectedInvalidCertificate
          | .compatGlobalSection xSol =>
              if checkInGlobalSolutionSet S η Apin cpin xSol then
                .verifiedCompatGlobalSection h0 h1
              else
                .rejectedInvalidCertificate
          | _ => .rejectedInvalidCertificate

/-! ### Part 4: Master Soundness & Mutual-Exclusion Theorems for `auditCellularSheafGate` -/

/-- Universal Structural Precedence Theorem (`Tribunal Condition C`):
    Any invalid complex/sheaf structure deterministically produces the exact highest-priority
    `StageCInvalidReasonQ0` regardless of the submitted `StageCCertBundleQ0`. -/
theorem thm_stageC_structural_invalid_universal
    (S : CellularSheafQ0) (η : VecQ0 S.N1)
    {nPin : Nat} (Apin : MatQ0 nPin S.N0) (cpin : VecQ0 nPin)
    (reason : StageCInvalidReasonQ0)
    (hval : validateSheafComplexStructure S = some reason) :
    ∀ bundle : StageCCertBundleQ0 S nPin,
      auditCellularSheafGate S η Apin cpin bundle = .rejectedInvalidComplexOrSheaf reason := by
  intro bundle
  simp [auditCellularSheafGate, hval]

theorem lem_validateSheaf_none_unpack {S : CellularSheafQ0}
    (hv : validateSheafComplexStructure S = none) :
    checkBoundaryNilpotent S = true ∧
    checkSheafUnitsAndContexts S = true ∧
    checkSheafFlagFunctoriality S = true ∧
    checkCochainNilpotent S = true ∧
    checkGlobalAuthorityMeet S = true := by
  unfold validateSheafComplexStructure at hv
  cases b1 : checkBoundaryNilpotent S
  · simp [b1] at hv
  · simp only [b1, Bool.not_true, Bool.false_eq_true, ↓reduceIte] at hv
    cases b2 : checkSheafUnitsAndContexts S
    · simp [b2] at hv
    · simp only [b2, Bool.not_true, Bool.false_eq_true, ↓reduceIte] at hv
      cases b3 : checkSheafFlagFunctoriality S
      · simp [b3] at hv
      · simp only [b3, Bool.not_true, Bool.false_eq_true, ↓reduceIte] at hv
        cases b4 : checkCochainNilpotent S
        · simp [b4] at hv
        · simp only [b4, Bool.not_true, Bool.false_eq_true, ↓reduceIte] at hv
          cases b5 : checkGlobalAuthorityMeet S
          · simp [b5] at hv
          · exact ⟨rfl, rfl, rfl, rfl, rfl⟩

/-- Master Soundness Theorem for `.verifiedCompatGlobalSection`:
    Guarantees full sheaf functoriality, cochain nilpotence, global 3D authority meet
    conservation, exact `CohomologyComplementBasis` (`h0, h1`), AND existence of a valid
    guarded global section `x ∈ S`. -/
theorem thm_stageC_compat_section_sound
    (S : CellularSheafQ0) (η : VecQ0 S.N1)
    {nPin : Nat} (Apin : MatQ0 nPin S.N0) (cpin : VecQ0 nPin)
    (bundle : StageCCertBundleQ0 S nPin) (h0 h1 : Nat)
    (hok : auditCellularSheafGate S η Apin cpin bundle = .verifiedCompatGlobalSection h0 h1) :
    checkSheafFlagFunctoriality S = true ∧
    checkCochainNilpotent S = true ∧
    (∀ v : Fin S.nV, AuthorityLe S.claimedGlobalAuth (S.vAuth v)) ∧
    checkCohomologyCert (assembleDelta0 S) (assembleDelta1 S) bundle.cohomCert = true ∧
    bundle.cohomCert.rn0.k = h0 ∧
    bundle.cohomCert.h1 = h1 ∧
    ∃ xSol : VecQ0 S.N0, InGlobalSolutionSet S η Apin cpin xSol := by
  unfold auditCellularSheafGate at hok
  cases hval : validateSheafComplexStructure S with
  | some r => rw [hval] at hok; contradiction
  | none =>
      rw [hval] at hok; dsimp only at hok
      rcases lem_validateSheaf_none_unpack hval with ⟨_, _, hfunc, hnil, hauth_b⟩
      have hauth := (thm_stageC_global_authority_meet_nonescalation S hauth_b).1
      cases hcc : checkCohomologyCert (assembleDelta0 S) (assembleDelta1 S) bundle.cohomCert with
      | false => simp [hcc] at hok
      | true =>
          simp only [hcc, Bool.not_true, Bool.false_eq_true, ↓reduceIte] at hok
          by_cases hcurv : !vecEqBool (matVec (assembleDelta1 S) η) (zeroVec S.N2)
          · simp only [hcurv, ↓reduceIte] at hok
            cases hp : bundle.payload <;> simp [hp] at hok
          · simp only [hcurv, Bool.false_eq_true, ↓reduceIte] at hok
            by_cases hobs : !vecEqBool (matVec bundle.cohomCert.LH η) (zeroVec bundle.cohomCert.h1)
            · simp only [hobs, ↓reduceIte] at hok
              cases hp : bundle.payload with
              | cohomologyObstruction yD =>
                  rw [hp] at hok; dsimp only at hok
                  cases hd : checkDualObstruction (assembleDelta0 S) η yD <;> simp [hd] at hok
              | _ => simp [hp] at hok
            · simp only [hobs, Bool.false_eq_true, ↓reduceIte] at hok
              cases hp : bundle.payload with
              | curvatureClaim => simp [hp] at hok
              | cohomologyObstruction _ => simp [hp] at hok
              | anchorOrGuardUnsat uc =>
                  rw [hp] at hok; dsimp only at hok
                  cases hu : checkGlobalUnsatCert S η Apin cpin uc <;> simp [hu] at hok
              | compatGlobalSection xSol =>
                  rw [hp] at hok; dsimp only at hok
                  cases hsol : checkInGlobalSolutionSet S η Apin cpin xSol with
                  | false => simp [hsol] at hok
                  | true =>
                      rw [hsol] at hok
                      simp only [↓reduceIte, StageCGateOutcomeQ0.verifiedCompatGlobalSection.injEq] at hok
                      exact ⟨hfunc, hnil, hauth, rfl, hok.1, hok.2,
                             xSol, (lem_checkInGlobalSolutionSet_iff S η Apin cpin xSol).mp hsol⟩

/-- Master Soundness & Exclusion Theorem for `.verifiedCohomologyObstruction`:
    Guarantees `δ¹ η = 0` (true 1-cocycle!), `LH η ≠ 0` (`h¹ ≥ 1` and non-zero class in `H¹`),
    `∀ x ∈ C⁰, δ⁰ x ≠ η` (hence `S = ∅`), AND excludes `.verifiedCompatGlobalSection` for ALL bundles! -/
theorem thm_stageC_cohomology_obstruction_sound_and_exclusive
    (S : CellularSheafQ0) (η : VecQ0 S.N1)
    {nPin : Nat} (Apin : MatQ0 nPin S.N0) (cpin : VecQ0 nPin)
    (bundle : StageCCertBundleQ0 S nPin) (h0 h1 : Nat)
    (hobs : auditCellularSheafGate S η Apin cpin bundle = .verifiedCohomologyObstruction h0 h1) :
    matVec (assembleDelta1 S) η = zeroVec S.N2 ∧
    matVec bundle.cohomCert.LH η ≠ zeroVec bundle.cohomCert.h1 ∧
    (∀ x : VecQ0 S.N0, matVec (assembleDelta0 S) x ≠ η) ∧
    (∀ b_any : StageCCertBundleQ0 S nPin, ∀ k0 k1 : Nat,
      auditCellularSheafGate S η Apin cpin b_any ≠ .verifiedCompatGlobalSection k0 k1) := by
  have core : matVec (assembleDelta1 S) η = zeroVec S.N2 ∧
              matVec bundle.cohomCert.LH η ≠ zeroVec bundle.cohomCert.h1 ∧
              (∀ x : VecQ0 S.N0, matVec (assembleDelta0 S) x ≠ η) := by
    unfold auditCellularSheafGate at hobs
    cases hval : validateSheafComplexStructure S with
    | some _ => rw [hval] at hobs; contradiction
    | none =>
        rw [hval] at hobs; dsimp only at hobs
        cases hcc : checkCohomologyCert (assembleDelta0 S) (assembleDelta1 S) bundle.cohomCert with
        | false => simp [hcc] at hobs
        | true =>
            simp only [hcc, Bool.not_true, Bool.false_eq_true, ↓reduceIte] at hobs
            cases hcurv : vecEqBool (matVec (assembleDelta1 S) η) (zeroVec S.N2) with
            | false =>
                simp only [hcurv, Bool.not_false, ↓reduceIte] at hobs
                cases hp : bundle.payload <;> simp [hp] at hobs
            | true =>
                simp only [hcurv, Bool.not_true, Bool.false_eq_true, ↓reduceIte] at hobs
                have hd1_zero : matVec (assembleDelta1 S) η = zeroVec S.N2 :=
                  (vecEqBool_iff _ _).mp hcurv
                cases hlh : vecEqBool (matVec bundle.cohomCert.LH η) (zeroVec bundle.cohomCert.h1) with
                | true =>
                    simp only [hlh, Bool.not_true, Bool.false_eq_true, ↓reduceIte] at hobs
                    cases hp : bundle.payload with
                    | curvatureClaim => simp [hp] at hobs
                    | cohomologyObstruction _ => simp [hp] at hobs
                    | anchorOrGuardUnsat uc =>
                        rw [hp] at hobs; dsimp only at hobs
                        cases hu : checkGlobalUnsatCert S η Apin cpin uc <;> simp [hu] at hobs
                    | compatGlobalSection xSol =>
                        rw [hp] at hobs; dsimp only at hobs
                        cases hs : checkInGlobalSolutionSet S η Apin cpin xSol <;> simp [hs] at hobs
                | false =>
                    simp only [hlh, Bool.not_false, ↓reduceIte] at hobs
                    have hlh_nz : matVec bundle.cohomCert.LH η ≠ zeroVec bundle.cohomCert.h1 :=
                      fun heq => by rw [(vecEqBool_iff _ _).mpr heq] at hlh; contradiction
                    cases hp : bundle.payload with
                    | cohomologyObstruction yDual =>
                        rw [hp] at hobs; dsimp only at hobs
                        cases hdual : checkDualObstruction (assembleDelta0 S) η yDual with
                        | false => simp [hdual] at hobs
                        | true =>
                            exact ⟨hd1_zero, hlh_nz,
                                   thm_dual_obstruction_not_in_image (assembleDelta0 S) η yDual hdual⟩
                    | _ => simp [hp] at hobs
  refine ⟨core.1, core.2.1, core.2.2, ?_⟩
  intro b_any k0 k1 hcompat
  rcases (thm_stageC_compat_section_sound S η Apin cpin b_any k0 k1 hcompat).2.2.2.2.2.2 with ⟨xSol, hx⟩
  exact core.2.2 xSol hx.1

/-- Master Soundness & Exclusion Theorem for `.verifiedFaceCurvatureFailure`:
    Guarantees `δ¹ η ≠ 0` AND `∀ x ∈ C⁰, δ⁰ x ≠ η` (even when `h¹ = 0`!), excluding
    both `.verifiedCompatGlobalSection` and `.verifiedCohomologyObstruction`. -/
theorem thm_stageC_face_curvature_sound_and_exclusive
    (S : CellularSheafQ0) (η : VecQ0 S.N1)
    {nPin : Nat} (Apin : MatQ0 nPin S.N0) (cpin : VecQ0 nPin)
    (bundle : StageCCertBundleQ0 S nPin) (h0 h1 : Nat)
    (hcurv : auditCellularSheafGate S η Apin cpin bundle = .verifiedFaceCurvatureFailure h0 h1) :
    matVec (assembleDelta1 S) η ≠ zeroVec S.N2 ∧
    (∀ x : VecQ0 S.N0, matVec (assembleDelta0 S) x ≠ η) ∧
    (∀ b_any : StageCCertBundleQ0 S nPin, ∀ k0 k1 : Nat,
      auditCellularSheafGate S η Apin cpin b_any ≠ .verifiedCompatGlobalSection k0 k1 ∧
      auditCellularSheafGate S η Apin cpin b_any ≠ .verifiedCohomologyObstruction k0 k1) := by
  have core : checkCochainNilpotent S = true ∧ matVec (assembleDelta1 S) η ≠ zeroVec S.N2 := by
    unfold auditCellularSheafGate at hcurv
    cases hval : validateSheafComplexStructure S with
    | some _ => rw [hval] at hcurv; contradiction
    | none =>
        rw [hval] at hcurv; dsimp only at hcurv
        have hnil := (lem_validateSheaf_none_unpack hval).2.2.2.1
        cases hcc : checkCohomologyCert (assembleDelta0 S) (assembleDelta1 S) bundle.cohomCert with
        | false => simp [hcc] at hcurv
        | true =>
            simp only [hcc, Bool.not_true, Bool.false_eq_true, ↓reduceIte] at hcurv
            cases hb : vecEqBool (matVec (assembleDelta1 S) η) (zeroVec S.N2) with
            | true =>
                simp only [hb, Bool.not_true, Bool.false_eq_true, ↓reduceIte] at hcurv
                by_cases hobs : !vecEqBool (matVec bundle.cohomCert.LH η) (zeroVec bundle.cohomCert.h1)
                · simp only [hobs, ↓reduceIte] at hcurv
                  cases hp : bundle.payload with
                  | cohomologyObstruction yD =>
                      rw [hp] at hcurv; dsimp only at hcurv
                      cases hd : checkDualObstruction (assembleDelta0 S) η yD <;> simp [hd] at hcurv
                  | _ => simp [hp] at hcurv
                · simp only [hobs, Bool.false_eq_true, ↓reduceIte] at hcurv
                  cases hp : bundle.payload with
                  | curvatureClaim => simp [hp] at hcurv
                  | cohomologyObstruction _ => simp [hp] at hcurv
                  | anchorOrGuardUnsat uc =>
                      rw [hp] at hcurv; dsimp only at hcurv
                      cases hu : checkGlobalUnsatCert S η Apin cpin uc <;> simp [hu] at hcurv
                  | compatGlobalSection xSol =>
                      rw [hp] at hcurv; dsimp only at hcurv
                      cases hs : checkInGlobalSolutionSet S η Apin cpin xSol <;> simp [hs] at hcurv
            | false =>
                have hnz : matVec (assembleDelta1 S) η ≠ zeroVec S.N2 :=
                  fun heq => by rw [(vecEqBool_iff _ _).mpr heq] at hb; contradiction
                exact ⟨hnil, hnz⟩
  have hno_prim : ∀ x : VecQ0 S.N0, matVec (assembleDelta0 S) x ≠ η := by
    intro x hx
    have h0 := thm_cochain_nilpotent_sound S core.1 x
    rw [hx] at h0
    exact core.2 h0
  refine ⟨core.2, hno_prim, fun b_any k0 k1 => ⟨?_, ?_⟩⟩
  · intro hcompat
    rcases (thm_stageC_compat_section_sound S η Apin cpin b_any k0 k1 hcompat).2.2.2.2.2.2 with ⟨xSol, hx⟩
    exact hno_prim xSol hx.1
  · intro hobs
    have hd1_0 := (thm_stageC_cohomology_obstruction_sound_and_exclusive S η Apin cpin b_any k0 k1 hobs).1
    exact core.2 hd1_0

/-- Master Soundness & Exclusion Theorem for `.verifiedAnchorOrGuardIncompatibility` (`Condition B`):
    Guarantees BOTH `∃ x_lin, δ⁰ x_lin = η` (`η ∈ im(δ⁰)`, e.g. even when `H¹ = 0`!) AND
    `∀ x ∈ C⁰, ¬ InGlobalSolutionSet S η Apin cpin x` (`S = ∅`), excluding `.verifiedCompatGlobalSection`
    for ALL candidate bundles! -/
theorem thm_stageC_incompatibility_sound_and_exclusive
    (S : CellularSheafQ0) (η : VecQ0 S.N1)
    {nPin : Nat} (Apin : MatQ0 nPin S.N0) (cpin : VecQ0 nPin)
    (bundle : StageCCertBundleQ0 S nPin) (h0 h1 : Nat)
    (hinc : auditCellularSheafGate S η Apin cpin bundle = .verifiedAnchorOrGuardIncompatibility h0 h1) :
    (∃ x_lin : VecQ0 S.N0, matVec (assembleDelta0 S) x_lin = η) ∧
    (∀ x : VecQ0 S.N0, ¬ InGlobalSolutionSet S η Apin cpin x) ∧
    (∀ b_any : StageCCertBundleQ0 S nPin, ∀ k0 k1 : Nat,
      auditCellularSheafGate S η Apin cpin b_any ≠ .verifiedCompatGlobalSection k0 k1) := by
  have core : (∃ x_lin : VecQ0 S.N0, matVec (assembleDelta0 S) x_lin = η) ∧
              (∀ x : VecQ0 S.N0, ¬ InGlobalSolutionSet S η Apin cpin x) := by
    unfold auditCellularSheafGate at hinc
    cases hval : validateSheafComplexStructure S with
    | some _ => rw [hval] at hinc; contradiction
    | none =>
        rw [hval] at hinc; dsimp only at hinc
        cases hcc : checkCohomologyCert (assembleDelta0 S) (assembleDelta1 S) bundle.cohomCert with
        | false => simp [hcc] at hinc
        | true =>
            simp only [hcc, Bool.not_true, Bool.false_eq_true, ↓reduceIte] at hinc
            cases hd1 : vecEqBool (matVec (assembleDelta1 S) η) (zeroVec S.N2) with
            | false =>
                simp only [hd1, Bool.not_false, ↓reduceIte] at hinc
                cases hp : bundle.payload <;> simp [hp] at hinc
            | true =>
                simp only [hd1, Bool.not_true, Bool.false_eq_true, ↓reduceIte] at hinc
                cases hlh : vecEqBool (matVec bundle.cohomCert.LH η) (zeroVec bundle.cohomCert.h1) with
                | false =>
                    simp only [hlh, Bool.not_false, ↓reduceIte] at hinc
                    cases hp : bundle.payload with
                    | cohomologyObstruction yD =>
                        rw [hp] at hinc; dsimp only at hinc
                        cases hd : checkDualObstruction (assembleDelta0 S) η yD <;> simp [hd] at hinc
                    | _ => simp [hp] at hinc
                | true =>
                    simp only [hlh, Bool.not_true, Bool.false_eq_true, ↓reduceIte] at hinc
                    have hd1_eq := (vecEqBool_iff _ _).mp hd1
                    have hlh_eq := (vecEqBool_iff _ _).mp hlh
                    have hex_lin := ((thm_h1_quotient_decomp_unique (assembleDelta0 S) (assembleDelta1 S)
                      bundle.cohomCert hcc).2.2.2.1 η hd1_eq).mpr hlh_eq
                    cases hp : bundle.payload with
                    | curvatureClaim => simp [hp] at hinc
                    | cohomologyObstruction _ => simp [hp] at hinc
                    | compatGlobalSection xSol =>
                        rw [hp] at hinc; dsimp only at hinc
                        cases hs : checkInGlobalSolutionSet S η Apin cpin xSol <;> simp [hs] at hinc
                    | anchorOrGuardUnsat uc =>
                        rw [hp] at hinc; dsimp only at hinc
                        cases huc : checkGlobalUnsatCert S η Apin cpin uc with
                        | false => simp [huc] at hinc
                        | true =>
                            exact ⟨hex_lin, thm_stageC_anchor_guard_unsat_sound S η Apin cpin uc huc⟩
  refine ⟨core.1, core.2, ?_⟩
  intro b_any k0 k1 hcompat
  rcases (thm_stageC_compat_section_sound S η Apin cpin b_any k0 k1 hcompat).2.2.2.2.2.2 with ⟨xSol, hx⟩
  exact core.2 xSol hx

end GrandZero.StageC
