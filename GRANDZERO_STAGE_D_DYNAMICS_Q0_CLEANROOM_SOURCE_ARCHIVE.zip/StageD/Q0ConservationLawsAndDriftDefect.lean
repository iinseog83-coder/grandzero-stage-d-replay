/-
  GRANDZERO Ω — Stage D (Algebraic Dynamics, Invariants, Barriers & Memory Gate)
  Module D-2: Q0ConservationLawsAndDriftDefect.lean
  Scope:
    1. Exact symbolic partial differentiation `diffPoly` & rational quotient differentiation
       `diffGPR` over `StageA.PolyQ0`, plus formal polynomial Lie derivative `formalLieDerivPoly`.
    2. Exact discrete conservation law certification `checkDiscreteInvariantCert` via
       `StageB.substMap` & `StageA.auditProof`, proving all-time (`∀ t ∈ ℕ`) pole-free
       conservation `thm_discrete_invariant_all_time`.
    3. Exact 1-step discretization drift defect `stepDriftExpr` & `computeStepDrift`
       (`thm_step_drift_sound`, `thm_drift_witness_blocks_invariant`), strictly separating
       continuous Lie annihilation `L_F I = 0` from discrete step conservation (`F-D01`).
-/

import StageD.Q0GuardedDiscreteDynamicsAndTrajectories

namespace GrandZero.StageD

open GrandZero.StageA
open GrandZero.StageB
open GrandZero.StageC

/-! ### Part 1: Formal Symbolic Differentiation & Polynomial Lie Derivatives over `PolyQ0` -/

/-- Differentiate a monomial `m` with respect to variable `varIdx`:
    returns `some (exp, m_decremented)` if `exp ≥ 1`, or `none` if `varIdx` does not appear. -/
def diffMonomExp : Nat → Monom → Option (Nat × Monom)
  | _, [] => none
  | 0, e :: es =>
      if e = 0 then none else some (e, trimMonom ((e - 1) :: es))
  | k + 1, e :: es =>
      match diffMonomExp k es with
      | none          => none
      | some ( deg, es' ) => some (deg, trimMonom (e :: es'))

def diffTerms (varIdx : Nat) : List (Monom × Rat) → List (Monom × Rat)
  | [] => []
  | (m, c) :: rest =>
      match diffMonomExp varIdx m with
      | none          => diffTerms varIdx rest
      | some (deg, m') => (m', c * (deg : Rat)) :: diffTerms varIdx rest

/-- Exact partial derivative `∂_{x_{varIdx}} p` on canonical sparse polynomials `PolyQ0`. -/
def diffPoly (varIdx : Nat) (p : PolyQ0) : PolyQ0 :=
  ⟨canonTerms (diffTerms varIdx p.terms)⟩

theorem thm_diffPoly_const (varIdx : Nat) (c : Rat) :
    diffPoly varIdx (PolyQ0.const c) = PolyQ0.zero := by
  unfold PolyQ0.const diffPoly
  by_cases hc : c = 0
  · simp [hc, diffTerms, canonTerms, PolyQ0.zero]
  · simp [hc, diffTerms, diffMonomExp, canonTerms, PolyQ0.zero]

theorem lem_diffMonomExp_varMonom :
    ∀ s : Nat, diffMonomExp s (varMonom s) = some (1, [])
  | 0 => rfl
  | s + 1 => by
      simp [varMonom, diffMonomExp, lem_diffMonomExp_varMonom s, trimMonom]

theorem thm_diffPoly_var_self (s : Nat) :
    diffPoly s (PolyQ0.var s) = PolyQ0.one := by
  simp [PolyQ0.var, diffPoly, diffTerms, lem_diffMonomExp_varMonom s,
        canonTerms, insertTerm, insertTermAux, trimMonom, PolyQ0.one]

/-- Formal polynomial Lie derivative `L_F P = ∑_j (∂_{x_j} P) · F_j` over `PolyQ0`. -/
def lieDerivPolyAux (idx : Nat) (p : PolyQ0) : List PolyQ0 → PolyQ0
  | []      => PolyQ0.zero
  | f :: fs => polyAdd (polyMul (diffPoly idx p) f) (lieDerivPolyAux (idx + 1) p fs)

def formalLieDerivPoly (p : PolyQ0) (ratePolys : List PolyQ0) : PolyQ0 :=
  canonPoly (lieDerivPolyAux 0 p ratePolys)

/-- Reflect a list of polynomial (denominator-1) rate expressions into `List PolyQ0`. -/
def reflectPolyRateList (Γ : VarCtxQ0) : List ExprQ0 → Option (List PolyQ0)
  | [] => some []
  | r :: rs =>
      match reflectExpr Γ r, reflectPolyRateList Γ rs with
      | some rr, some rest =>
          if canonPoly rr.den == PolyQ0.one then some (rr.num :: rest)
          else none
      | _, _ => none

/-- Compute exact formal polynomial Lie derivative `L_F obs` when `obs` and `rates` have
    constant unit denominator `PolyQ0.one`. -/
def computePolyLieDeriv (Γ : VarCtxQ0) (obs : ExprQ0) (rates : List ExprQ0) : Option PolyQ0 :=
  match reflectExpr Γ obs, reflectPolyRateList Γ rates with
  | some rObs, some ratePolys =>
      if canonPoly rObs.den == PolyQ0.one then
        some (formalLieDerivPoly rObs.num ratePolys)
      else
        none
  | _, _ => none

/-! ### Part 2: Exact Discrete Conservation Laws (`thm_discrete_invariant_all_time`) -/

/-- Pull back a scalar observable `obs` along one discrete transition step `D.stepCoords`. -/
def pulledObsExpr (D : GuardedDynSpecQ0) (obs : ExprQ0) : ExprQ0 :=
  substMap D.stepCoords obs

/-- Whitebox discrete conservation certificate supporting both `StageA.auditProof` (`ProofCertQ0`)
    and `StageB` SOS/cone pole-discharged rational reflection (`BridgeGuardProofQ0`). -/
inductive DiscreteInvariantCertQ0 where
  | viaStageAAudit   (cert : ProofCertQ0)
  | viaBridgePoleGPR (pulledPoles : List BridgeGuardProofQ0) (obsPoles : List BridgeGuardProofQ0)
  deriving DecidableEq, Repr, Inhabited

/-- Whitebox checker certifying `obs(Φ(x)) ≡_{StrongEq} obs(x)` across `Real_ℚ(D.ctx)`. -/
def checkDiscreteInvariantCert
    (D : GuardedDynSpecQ0) (obs : ExprQ0) (ic : DiscreteInvariantCertQ0) : Bool :=
  if !(checkDynUnitsOnly D && (synthUnit D.ctx.vars obs).isSome) then false
  else
    match ic with
    | .viaStageAAudit cert =>
        auditProof D.ctx.vars D.ctx.hyps D.ctx.guards cert (pulledObsExpr D obs) obs == SyndromeQ0.zero
    | .viaBridgePoleGPR pulledPoles obsPoles =>
        match reflectExpr D.ctx.vars (pulledObsExpr D obs), reflectExpr D.ctx.vars obs with
        | some rPull, some rObs =>
            (rPull.unit == rObs.unit) &&
            checkBridgeGuardList D.ctx.vars D.ctx.hyps D.ctx.guards pulledPoles rPull.guards &&
            checkBridgeGuardList D.ctx.vars D.ctx.hyps D.ctx.guards obsPoles rObs.guards &&
            (canonPoly (polySub (polyMul rPull.num rObs.den) (polyMul rObs.num rPull.den)) == PolyQ0.zero)
        | _, _ => false

theorem lem_invariant_cert_strongEq
    (D : GuardedDynSpecQ0) (obs : ExprQ0) (ic : DiscreteInvariantCertQ0)
    (hinv_cert : checkDiscreteInvariantCert D obs ic = true)
    (ρ : List Rat) (hdom : ValidDomainQ0 ρ D.ctx) :
    StrongEq ρ (pulledObsExpr D obs) obs := by
  unfold checkDiscreteInvariantCert at hinv_cert
  cases hpre : (checkDynUnitsOnly D && (synthUnit D.ctx.vars obs).isSome) with
  | false => simp [hpre] at hinv_cert
  | true =>
      simp only [hpre, Bool.not_true, Bool.false_eq_true, ↓reduceIte] at hinv_cert
      rcases hdom with ⟨henv, hhyps, hguards⟩
      cases ic with
      | viaStageAAudit cert =>
          simp only [beq_iff_eq] at hinv_cert
          exact (thm_syndrome_sound cert D.ctx.vars D.ctx.hyps D.ctx.guards
            (pulledObsExpr D obs) obs hinv_cert).2 ρ henv hhyps hguards
      | viaBridgePoleGPR pulledPoles obsPoles =>
          cases hrP : reflectExpr D.ctx.vars (pulledObsExpr D obs) with
          | none => rw [hrP] at hinv_cert; contradiction
          | some rPull =>
            cases hrO : reflectExpr D.ctx.vars obs with
            | none => rw [hrP, hrO] at hinv_cert; contradiction
            | some rObs =>
                rw [hrP, hrO] at hinv_cert
                simp only [Bool.and_eq_true, beq_iff_eq] at hinv_cert
                rcases hinv_cert with ⟨⟨⟨_, hp_pull⟩, hp_obs⟩, hcross⟩
                have hg_pull := thm_bridge_guard_list_sound D.ctx.vars D.ctx.hyps D.ctx.guards
                  ρ henv hhyps hguards pulledPoles rPull.guards hp_pull
                have hg_obs := thm_bridge_guard_list_sound D.ctx.vars D.ctx.hyps D.ctx.guards
                  ρ henv hhyps hguards obsPoles rObs.guards hp_obs
                rcases thm_gpr_value_sound (pulledObsExpr D obs) D.ctx.vars ρ rPull henv hrP hg_pull with
                  ⟨hdenP_nz, hevP⟩
                rcases thm_gpr_value_sound obs D.ctx.vars ρ rObs henv hrO hg_obs with
                  ⟨hdenO_nz, hevO⟩
                have hzero := canonPoly_eq_zero_sound hcross ρ
                rw [evalPoly_sub, evalPoly_mul, evalPoly_mul] at hzero
                have hfrac_eq := rat_eq_of_cross_sub_zero
                  (evalPoly ρ rPull.num) (evalPoly ρ rPull.den)
                  (evalPoly ρ rObs.num) (evalPoly ρ rObs.den)
                  hdenP_nz hdenO_nz hzero
                exact ⟨evalPoly ρ rObs.num / evalPoly ρ rObs.den, by rw [hevP, hfrac_eq], hevO⟩

/-- One-Step Exact Discrete Conservation Theorem:
    Whenever `checkDiscreteInvariantCert D obs ic = true`, for any `ρ ∈ Real_ℚ(D.ctx)` whose
    next state evaluates to `evalCoords ρ D.stepCoords = some ρ'`, BOTH `obs(ρ)` and `obs(ρ')`
    are pole-free (`some val`) and identically equal (`denoteExpr ρ' obs = denoteExpr ρ obs`). -/
theorem thm_discrete_invariant_one_step
    (D : GuardedDynSpecQ0) (obs : ExprQ0) (ic : DiscreteInvariantCertQ0)
    (hinv_cert : checkDiscreteInvariantCert D obs ic = true)
    (ρ ρ' : List Rat)
    (hdom : ValidDomainQ0 ρ D.ctx)
    (hstep : evalCoords ρ D.stepCoords = some ρ') :
    ∃ val : Rat, denoteExpr ρ obs = some val ∧ denoteExpr ρ' obs = some val := by
  have hstrong := lem_invariant_cert_strongEq D obs ic hinv_cert ρ hdom
  unfold checkDiscreteInvariantCert at hinv_cert
  cases hpre : (checkDynUnitsOnly D && (synthUnit D.ctx.vars obs).isSome) with
  | false => simp [hpre] at hinv_cert
  | true =>
      simp only [Bool.and_eq_true] at hpre
      rcases hpre with ⟨hdyn_u, hu_some⟩
      unfold checkDynUnitsOnly checkBridgeUnitsOnly GuardedDynSpecQ0.toStepBridge at hdyn_u
      simp only [Bool.and_eq_true] at hdyn_u
      have hlen_coords : D.stepCoords.length = D.ctx.vars.length :=
        checkCoordsUnits_length hdyn_u.1.2
      cases hu_obs : synthUnit D.ctx.vars obs with
      | none => rw [hu_obs] at hu_some; contradiction
      | some u_obs =>
          have hws_obs : wellScoped D.stepCoords.length obs = true := by
            rw [hlen_coords]
            exact synthUnit_imp_wellScoped obs hu_obs
          rcases hstrong with ⟨val, hpulled, hobs⟩
          unfold pulledObsExpr at hpulled
          rw [lem_substMap_denote obs hstep hws_obs] at hpulled
          exact ⟨val, hobs, hpulled⟩

/-- Target Theorem `thm_discrete_invariant_all_time`:
    Combining `ForwardInvariant D` with `checkDiscreteInvariantCert D obs ic = true` proves
    that for EVERY `ρ₀ ∈ Real_ℚ(D.ctx)` and EVERY time step `t ∈ ℕ`, the trajectory state `ρt`
    is well-defined and `obs(ρt) = obs(ρ₀)` (with zero division-by-zero poles at any step). -/
theorem thm_discrete_invariant_all_time
    (D : GuardedDynSpecQ0) (obs : ExprQ0) (ic : DiscreteInvariantCertQ0)
    (hfwd : ForwardInvariant D)
    (hinv_cert : checkDiscreteInvariantCert D obs ic = true)
    (ρ₀ : List Rat) (h₀ : ValidDomainQ0 ρ₀ D.ctx) :
    ∀ t : Nat, ∃ (ρt : List Rat) (val₀ : Rat),
      iterateStep D.stepCoords t ρ₀ = some ρt ∧
      ValidDomainQ0 ρt D.ctx ∧
      denoteExpr ρ₀ obs = some val₀ ∧
      denoteExpr ρt obs = some val₀
  | 0 => by
      rcases hfwd ρ₀ h₀ with ⟨ρ₁, hstep0, _⟩
      rcases thm_discrete_invariant_one_step D obs ic hinv_cert ρ₀ ρ₁ h₀ hstep0 with ⟨val₀, hd0, _⟩
      exact ⟨ρ₀, val₀, rfl, h₀, hd0, hd0⟩
  | t + 1 => by
      rcases thm_discrete_invariant_all_time D obs ic hfwd hinv_cert ρ₀ h₀ t with
        ⟨ρt, val₀, hit, hvt, hd0, hdt⟩
      rcases hfwd ρt hvt with ⟨ρ_next, hstep_t, hv_next⟩
      rcases thm_discrete_invariant_one_step D obs ic hinv_cert ρt ρ_next hvt hstep_t with
        ⟨vt, hdt', hd_next⟩
      rw [hdt] at hdt'
      injection hdt' with hv_eq
      subst hv_eq
      exact ⟨ρ_next, val₀, by simp [iterateStep, hit, hstep_t], hv_next, hd0, hd_next⟩

/-! ### Part 3: Exact 1-Step Discretization Drift Defect (`stepDriftExpr`, `F-D01`) -/

/-- Exact 1-step observable drift expression `Δ_Φ obs(x) := obs(Φ(x)) - obs(x)`. -/
def stepDriftExpr (D : GuardedDynSpecQ0) (obs : ExprQ0) : ExprQ0 :=
  .binOp .sub (pulledObsExpr D obs) obs

/-- Reflect `Δ_Φ obs` into canonical rational form `num(x) / den(x)` via `StageA.reflectExpr`. -/
def computeStepDrift (D : GuardedDynSpecQ0) (obs : ExprQ0) : Option GPRResultQ0 :=
  if !checkDynUnitsOnly D then none
  else reflectExpr D.ctx.vars (stepDriftExpr D obs)

/-- Target Theorem `thm_step_drift_sound`:
    Whenever `computeStepDrift D obs = some rΔ` and `denoteExpr ρ (stepDriftExpr D obs) = some d`
    on `ρ ∈ Real_ℚ(D.ctx)` with `evalCoords ρ D.stepCoords = some ρ'`, `rΔ.den(ρ) ≠ 0` and
    `d = obs(ρ') - obs(ρ) = evalPoly ρ rΔ.num / evalPoly ρ rΔ.den`. -/
theorem thm_step_drift_sound
    (D : GuardedDynSpecQ0) (obs : ExprQ0) (rΔ : GPRResultQ0)
    (hcomp : computeStepDrift D obs = some rΔ)
    (ρ : List Rat) (hdom : ValidDomainQ0 ρ D.ctx)
    (d : Rat) (hd : denoteExpr ρ (stepDriftExpr D obs) = some d) :
    evalPoly ρ rΔ.den ≠ 0 ∧
    d = evalPoly ρ rΔ.num / evalPoly ρ rΔ.den := by
  unfold computeStepDrift at hcomp
  cases hu : checkDynUnitsOnly D with
  | false => simp [hu] at hcomp
  | true =>
      simp only [hu, Bool.not_true, Bool.false_eq_true, ↓reduceIte] at hcomp
      have hisSome : (denoteExpr ρ (stepDriftExpr D obs)).isSome = true := by simp [hd]
      have hg := (thm_gpr_domain_exact (stepDriftExpr D obs) D.ctx.vars ρ rΔ hdom.1 hcomp).mpr hisSome
      rcases thm_gpr_value_sound (stepDriftExpr D obs) D.ctx.vars ρ rΔ hdom.1 hcomp hg with ⟨hden_nz, hval⟩
      rw [hd] at hval
      injection hval with hd_eq
      exact ⟨hden_nz, hd_eq⟩

/-- Executable witness check certifying non-zero 1-step discretization drift at `ρ₀ ∈ Real_ℚ(D.ctx)`. -/
def checkStepDriftWitness (D : GuardedDynSpecQ0) (obs : ExprQ0) (ρ₀ : List Rat) : Bool :=
  checkDynUnitsOnly D &&
  checkValidDomainQ0 ρ₀ D.ctx &&
  match denoteExpr ρ₀ (stepDriftExpr D obs) with
  | some d => decide (d ≠ 0)
  | none   => false

/-- Universal Exclusion Theorem `thm_drift_witness_blocks_invariant`:
    A verified 1-step drift witness at `ρ₀ ∈ Real_ℚ(D.ctx)` proves `Δ_Φ obs(ρ₀) ≠ 0` and
    universally blocks `checkDiscreteInvariantCert D obs ic` for ALL `ic : DiscreteInvariantCertQ0`. -/
theorem thm_drift_witness_blocks_invariant
    (D : GuardedDynSpecQ0) (obs : ExprQ0) (ρ₀ : List Rat)
    (hw : checkStepDriftWitness D obs ρ₀ = true) :
    ValidDomainQ0 ρ₀ D.ctx ∧
    (∃ d : Rat, denoteExpr ρ₀ (stepDriftExpr D obs) = some d ∧ d ≠ 0) ∧
    (∀ ic : DiscreteInvariantCertQ0, checkDiscreteInvariantCert D obs ic = false) := by
  unfold checkStepDriftWitness at hw
  cases h1 : checkDynUnitsOnly D with
  | false => simp [h1] at hw
  | true =>
    cases h2 : checkValidDomainQ0 ρ₀ D.ctx with
    | false => simp [h1, h2] at hw
    | true =>
      simp only [h1, h2, Bool.true_and] at hw
      cases hd : denoteExpr ρ₀ (stepDriftExpr D obs) with
      | none => rw [hd] at hw; contradiction
      | some d =>
          rw [hd] at hw
          simp only [decide_eq_true_eq] at hw
          have hdom : ValidDomainQ0 ρ₀ D.ctx := (lem_checkValidDomain_iff ρ₀ D.ctx).mp h2
          refine ⟨hdom, ⟨d, rfl, hw⟩, ?_⟩
          intro ic
          cases hcert : checkDiscreteInvariantCert D obs ic with
          | false => rfl
          | true =>
              rcases lem_invariant_cert_strongEq D obs ic hcert ρ₀ hdom with ⟨val, hp, ho⟩
              have hzero : denoteExpr ρ₀ (stepDriftExpr D obs) = some (val - val) := by
                simp [stepDriftExpr, denoteExpr, evalBinOp, hp, ho]
              rw [hd] at hzero
              injection hzero with heq
              have hvv : val - val = 0 := by grind
              rw [hvv] at heq
              exact False.elim (hw heq)

end GrandZero.StageD
