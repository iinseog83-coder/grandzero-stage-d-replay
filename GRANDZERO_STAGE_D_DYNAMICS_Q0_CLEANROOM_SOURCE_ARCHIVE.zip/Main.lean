/-
  GRANDZERO Ω — Stage D (Algebraic Dynamics, Invariants, Barriers & Memory Gate)
  Structured Audit Executable (`stage_d_audit`)
  Note: Every boolean printed below is computed dynamically at runtime by the
        Lean kernel functions (zero hardcoded `"true"` literals).
-/

import StageD

open GrandZero.StageA
open GrandZero.StageB
open GrandZero.StageC
open GrandZero.StageD

def main : IO Unit := do
  IO.println "========================================================================"
  IO.println "GRANDZERO OMEGA — STAGE D ALGEBRAIC DYNAMICS, BARRIERS & MEMORY AUDIT"
  IO.println "========================================================================"

  let mut allVectorsOk := true
  for rec in stageDVectorRecords do
    let matched := decide (rec.expected = rec.actual)
    if !matched then
      allVectorsOk := false
    IO.println s!"VECTOR|ID={rec.vecId}|EXPECTED={formatStageDOutcome rec.expected}|ACTUAL={formatStageDOutcome rec.actual}|MATCH={matched}|DETAIL={rec.detail}"

  -- Live runtime verification of F-D01 (exact Euler drift Δt² ω² H, 0 at origin, Lie derivative = 0)
  let lieZero := computePolyLieDeriv td01_ctx.vars td01_H td01_rates == some PolyQ0.zero
  let eulerFormulaEq :=
    auditProof td01_ctx.vars [] [] (.gprAstCert [] [])
      (stepDriftExpr td02_dyn td01_H) td02_exactDriftFormula == SyndromeQ0.zero
  let eulerOriginZero := denoteExpr [0, 0, 3, 2] (stepDriftExpr td02_dyn td01_H) == some 0
  let eulerNonTrivVal := denoteExpr [2, 0, 3, 1 / 2] (stepDriftExpr td02_dyn td01_H) == some (81 / 2)
  IO.println s!"EXTRA|ID=TD-02-FD01-DRIFT|LIE_ZERO={lieZero}|EXACT_DT2_OMEGA2_H={eulerFormulaEq}|ORIGIN_ZERO={eulerOriginZero}|SAMPLE_VAL_OK={eulerNonTrivVal}"

  -- Live runtime verification of F-D02 (H⁰ tear ≠ 0 while H¹ class coordinate LH(δ⁰(A₀ x₀)) == 0 on h¹ = 1 cycle)
  let tearCoboundaryNz := !vecEqBool (matVec (assembleDelta0 tc02_sheaf) (matVec td05_A0 td05_x0)) (zeroVec tc02_sheaf.N1)
  let tearH1ClassZero :=
    vecEqBool (matVec tc02_cohomCert.LH (matVec (assembleDelta0 tc02_sheaf) (matVec td05_A0 td05_x0)))
              (zeroVec tc02_cohomCert.h1)
  IO.println s!"EXTRA|ID=TD-05-FD02-COBOUNDARY|H0_TEAR_NONZERO={tearCoboundaryNz}|H1_CLASS_ZERO={tearH1ClassZero}"

  let allOk := allVectorsOk && lieZero && eulerFormulaEq && eulerOriginZero && eulerNonTrivVal && tearCoboundaryNz && tearH1ClassZero
  IO.println "------------------------------------------------------------------------"
  IO.println s!"ALL STAGE D DYNAMICAL, BARRIER & MEMORY VECTORS MATCH EXPECTED: {allOk}"
  if !allOk then
    throw (IO.userError "Stage D adversarial audit failed!")
